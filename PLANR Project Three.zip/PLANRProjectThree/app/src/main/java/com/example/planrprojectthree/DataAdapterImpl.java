package com.example.planrprojectthree;

import androidx.annotation.Nullable;

public class DataAdapterImpl extends DataAdapter {
    @Nullable
    @Override
    public CharSequence[] getAutofillOptions() {
        return super.getAutofillOptions();
    }
}
